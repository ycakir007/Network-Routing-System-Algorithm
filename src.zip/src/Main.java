//package src;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
//import java.util.Arrays;  //commented here
import java.util.StringTokenizer;

public class Main {

    // --- Data Structures ---

    // Hash table
    private static MyHashTable hostLookup = new MyHashTable();

    private static ArrayList<Host> hostsByIndex = new ArrayList<>();

    private static int totalUnsealedBackdoors = 0;


    private static ArrayList<Character> validChars_ = new ArrayList<>();
    static {
        char[] validChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_".toCharArray();
        for (char x : validChars) {
            validChars_.add(x);
        }
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java Main <input_file> <output_file>");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(args[0]));
             BufferedWriter writer = new BufferedWriter(new FileWriter(args[1]))) {

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                processCommand(line, writer);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void processCommand(String line, BufferedWriter writer) throws IOException {
        StringTokenizer st = new StringTokenizer(line);
        if (!st.hasMoreTokens()) return;
        String command = st.nextToken();

        switch (command) {
            case "spawn_host":
                handleSpawnHost(st, writer);
                break;
            case "link_backdoor":
                handleLinkBackdoor(st, writer);
                break;
            case "seal_backdoor":
                handleSealBackdoor(st, writer);
                break;
            case "trace_route":
                handleTraceRoute(st, writer);
                break;
            case "scan_connectivity":
                handleScanConnectivity(writer);
                break;
            case "simulate_breach":
                handleSimulateBreach(st, writer);
                break;
            case "oracle_report":
                handleOracleReport(writer);
                break;
        }
    }

    // --- 4.1 Spawning a Host ---
    // format spawn host <hostId> <clearanceLevel>
    private static void handleSpawnHost(StringTokenizer st, BufferedWriter writer) throws IOException {
        String id = st.nextToken();
        int clearance = Integer.parseInt(st.nextToken());

        // ID Character Validation
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            if (!validChars_.contains(c)) {
                writer.write("Some error occurred in spawn_host.\n");
                return;
            }
        }

        // NEW: Check using MyHashTable
        if (hostLookup.contains(id)) {
            writer.write("Some error occurred in spawn_host.\n");
            return;
        }

        // Create Host and assign index
        int newIndex = hostsByIndex.size();
        Host newHost = new Host(newIndex, id, clearance);

        hostsByIndex.add(newHost);

        // NEW: Insert directly into MyHashTable
        hostLookup.insert(newHost);

        writer.write("Spawned host " + id + " with clearance level " + clearance + ".\n");
    }

    // --- 4.2 Linking Backdoors ---
    // format link backdoor <hostId1> <hostId2> <latency> <bandwidth> <firewall level
    private static void handleLinkBackdoor(StringTokenizer st, BufferedWriter writer) throws IOException {
        String uId = st.nextToken();
        String vId = st.nextToken();
        int latency = Integer.parseInt(st.nextToken());
        int bandwidth = Integer.parseInt(st.nextToken());
        int firewall = Integer.parseInt(st.nextToken());

        // NEW: Direct Object Lookup
        Host u = hostLookup.get(uId);
        Host v = hostLookup.get(vId);

        if (u == null || v == null || uId.equals(vId)) {
            writer.write("Some error occurred in link_backdoor.\n");
            return;
        }

        if (u.hasTunnelTo(v.index)) {
            writer.write("Some error occurred in link_backdoor.\n");
            return;
        }

        Tunnel tUV = new Tunnel(v, latency, bandwidth, firewall);
        Tunnel tVU = new Tunnel(u, latency, bandwidth, firewall);
        u.tunnels.add(tUV);
        v.tunnels.add(tVU);
        totalUnsealedBackdoors++;

        writer.write("Linked " + uId + " <-> " + vId + " with latency " + latency + "ms, bandwidth " + bandwidth + "Mbps, firewall " + firewall + ".\n");
    }

    // --- 4.3 Sealing/Unsealing ---
    //format seal backdoor <hostId1> <hostId2>
    private static void handleSealBackdoor(StringTokenizer st, BufferedWriter writer) throws IOException {
        String uId = st.nextToken();
        String vId = st.nextToken();

        Host u = hostLookup.get(uId);
        Host v = hostLookup.get(vId);

        if (u == null || v == null) {
            writer.write("Some error occurred in seal_backdoor.\n");
            return;
        }

        Tunnel tUV = u.getTunnelTo(v.index);
        Tunnel tVU = v.getTunnelTo(u.index);

        if (tUV == null || tVU == null) {
            writer.write("Some error occurred in seal_backdoor.\n");
            return;
        }

        if (!tUV.isSealed) {
            tUV.isSealed = true;
            tVU.isSealed = true;
            totalUnsealedBackdoors--;
            writer.write("Backdoor " + uId + " <-> " + vId + " sealed.\n");
        } else {
            tUV.isSealed = false;
            tVU.isSealed = false;
            totalUnsealedBackdoors++;
            writer.write("Backdoor " + uId + " <-> " + vId + " unsealed.\n");
        }
    }

    // --- 4.4 Tracing Route ---
    //format trace route <sourceId> <destId> <min bandwidth> <lambda>
    private static void handleTraceRoute(StringTokenizer st, BufferedWriter writer) throws IOException {
        String srcId = st.nextToken();
        String dstId = st.nextToken();
        int minBw = Integer.parseInt(st.nextToken());
        int lambda = Integer.parseInt(st.nextToken());

        Host src = hostLookup.get(srcId);
        Host dst = hostLookup.get(dstId);

        if (src == null || dst == null) {
            writer.write("Some error occurred in trace_route.\n");
            return;
        }

        if (src.index == dst.index) {
            writer.write("Optimal route " + srcId + " -> " + dstId + ": " + srcId + " (Latency = 0ms)\n");
            return;
        }

        // --- Dijkstra Logic ---
        int[] minHops = new int[hostsByIndex.size()];

        for (int i = 0; i < minHops.length; i++) {
            minHops[i] = Integer.MAX_VALUE;
        }
       // Arrays.fill(minHops, Integer.MAX_VALUE);


        MyPriorityQueue pq = new MyPriorityQueue();
        RouteState startState = new RouteState(src, 0.0, 0, null);
        pq.add(startState);

        RouteState optimal = null;

        while (!pq.isEmpty()) {
            RouteState current = pq.poll();

            if (current.host.index == dst.index) {
                optimal = current;
                break;
            }

            if (current.hops >= minHops[current.host.index]) {
                continue;
            }
            minHops[current.host.index] = current.hops;

            for (Tunnel t : current.host.tunnels) {
                if (t.isSealed) continue;
                if (t.bandwidth < minBw) continue;
                if (current.host.clearance < t.firewall) continue;

                double segmentLatency = t.latency + (double)(lambda * current.hops);
                double newTotalLatency = current.totalLatency + segmentLatency;

                RouteState nextState = new RouteState(t.target, newTotalLatency, current.hops + 1, current);
                pq.add(nextState);
            }
        }

        if (optimal == null) {
            writer.write("No route found from " + srcId + " to " + dstId + "\n");
        } else {
            int displayLatency = (int) Math.round(optimal.totalLatency);
            StringBuilder sb = new StringBuilder();
            reconstructPath(optimal, sb);
            writer.write("Optimal route " + srcId + " -> " + dstId + ": " + sb.toString() +
                    " (Latency = " + displayLatency + "ms)\n");
        }
    }

    private static void reconstructPath(RouteState rs, StringBuilder sb) {
        if (rs.parent != null) {
            reconstructPath(rs.parent, sb);
            sb.append(" -> ");
        }
        sb.append(rs.host.id);
    }

    // --- 4.5 Connectivity Scan ---
    //scan connectivity
    private static void handleScanConnectivity(BufferedWriter writer) throws IOException {
        int connectedComponents = countConnectedComponents();
        if (hostsByIndex.size() <= 1 || connectedComponents <= 1) {
            writer.write("Network is fully connected.\n");
        } else {
            writer.write("Network has " + connectedComponents + " disconnected components.\n");
        }
    }

    private static int countConnectedComponents() {
        int size = hostsByIndex.size();
        if (size == 0) return 0;

        boolean[] visited = new boolean[size];
        int components = 0;

        for (int i = 0; i < size; i++) {
            if (!visited[i]) {
                components++;
                bfs(hostsByIndex.get(i), visited);
            }
        }
        return components;
    }

    private static void bfs(Host start, boolean[] visited) {
        ArrayList<Host> q = new ArrayList<>();
        q.add(start);
        visited[start.index] = true;

        int head = 0;
        while(head < q.size()){
            Host u = q.get(head++);
            for(Tunnel t : u.tunnels){
                if(!t.isSealed && !visited[t.target.index]){
                    visited[t.target.index] = true;
                    q.add(t.target);
                }
            }
        }
    }

    // --- 4.6 Simulate Breach ---

    //format  simulate breach <hostId>
    private static void handleSimulateBreach(StringTokenizer st, BufferedWriter writer) throws IOException {
        String arg1 = st.nextToken();

        if (!st.hasMoreTokens()) {
            // Host breach
            Host h = hostLookup.get(arg1);
            if (h == null) {
                writer.write("Some error occurred in simulate_breach.\n");
                return;
            }

            h.isHidden = false;
            int baseline = countConnectedComponentsHiddenAware();
            h.isHidden = true;
            int components = countConnectedComponentsHiddenAware();

            if (components > baseline) {
                writer.write("Host " + arg1 + " IS an articulation point.\n");
                writer.write("Failure results in " + components + " disconnected components.\n");
            } else {
                writer.write("Host " + arg1 + " is NOT an articulation point. Network remains the same.\n");
            }
            h.isHidden = false;

        } else {
            // Backdoor breach
            String uId = arg1;
            String vId = st.nextToken();
            Host u = hostLookup.get(uId);
            Host v = hostLookup.get(vId);

            if (u == null || v == null) {
                writer.write("Some error occurred in simulate_breach.\n");
                return;
            }

            if (!u.hasTunnelTo(v.index)) {
                writer.write("Some error occurred in simulate_breach.\n");
                return;
            }

            Tunnel tUV = u.getTunnelTo(v.index);
            Tunnel tVU = v.getTunnelTo(u.index);

            if (tUV.isSealed) {
                writer.write("Some error occurred in simulate_breach.\n");
                return;
            }

            int baseline = countConnectedComponentsHiddenAware();
            tUV.isSealed = true;
            tVU.isSealed = true;
            int components = countConnectedComponentsHiddenAware();

            if (components > baseline) {
                writer.write("Backdoor " + uId + " <-> " + vId + " IS a bridge.\n");
                writer.write("Failure results in " + components + " disconnected components.\n");
            } else {
                writer.write("Backdoor " + uId + " <-> " + vId + " is NOT a bridge. Network remains the same.\n");
            }
            tUV.isSealed = false;
            tVU.isSealed = false;
        }
    }

    private static int countConnectedComponentsHiddenAware() {
        int size = hostsByIndex.size();
        boolean[] visited = new boolean[size];
        int components = 0;

        for (int i = 0; i < size; i++) {
            Host h = hostsByIndex.get(i);
            if (!h.isHidden && !visited[i]) {
                components++;
                bfsHiddenAware(h, visited);
            }
        }
        return components;
    }

    private static void bfsHiddenAware(Host start, boolean[] visited) {
        ArrayList<Host> q = new ArrayList<>();
        q.add(start);
        visited[start.index] = true;

        int head = 0;
        while(head < q.size()){
            Host u = q.get(head++);
            for(Tunnel t : u.tunnels){
                if(!t.isSealed && !t.target.isHidden && !visited[t.target.index]){
                    visited[t.target.index] = true;
                    q.add(t.target);
                }
            }
        }
    }

    // --- 4.7 Oracle Report ---
    private static void handleOracleReport(BufferedWriter writer) throws IOException {
        writer.write("--- Resistance Network Report ---\n");
        int totalHosts = hostsByIndex.size();
        writer.write("Total Hosts: " + totalHosts + "\n");
        writer.write("Total Unsealed Backdoors: " + totalUnsealedBackdoors + "\n");

        int components = countConnectedComponents();
        boolean connected = (components <= 1) || (totalHosts <= 1);

        writer.write("Network Connectivity: " + (connected ? "Connected" : "Disconnected") + "\n");
        writer.write("Connected Components: " + components + "\n");

        boolean hasCycles = checkCycles();
        writer.write("Contains Cycles: " + (hasCycles ? "Yes" : "No") + "\n");

        BigDecimal totalClearance = BigDecimal.ZERO;
        BigDecimal sumBw = BigDecimal.ZERO;

        for(Host h : hostsByIndex) {
            totalClearance = totalClearance.add(new BigDecimal(h.clearance));
            for(Tunnel t : h.tunnels) {
                if(!t.isSealed) {
                    sumBw = sumBw.add(new BigDecimal(t.bandwidth));
                }
            }
        }

        BigDecimal avgBw = BigDecimal.ZERO;
        if(totalUnsealedBackdoors > 0) {
            BigDecimal denominator = new BigDecimal(totalUnsealedBackdoors).multiply(new BigDecimal(2));
            avgBw = sumBw.divide(denominator, 1, RoundingMode.HALF_UP);
        }

        BigDecimal avgClearance = BigDecimal.ZERO;
        if(totalHosts > 0) {
            avgClearance = totalClearance.divide(new BigDecimal(totalHosts), 1, RoundingMode.HALF_UP);
        }

        writer.write("Average Bandwidth: " + avgBw + "Mbps\n");
        writer.write("Average Clearance Level: " + avgClearance + "\n");
    }
// --- 4.7 Cycle Detection (Iterative BFS - Stack Safe) ---

    private static boolean checkCycles() {
        int size = hostsByIndex.size();
        boolean[] visited = new boolean[size];
        int[] parent = new int[size];

        // Initialize parent array with -1

        for (int i = 0; i < parent.length; i++) {
            parent[i] = -1;
        }
      //  Arrays.fill(parent, -1);

        for (Host h : hostsByIndex) {
            if (!visited[h.index]) {
                if (bfsCheckCycle(h, visited, parent)) return true;
            }
        }
        return false;
    }

    private static boolean bfsCheckCycle(Host start, boolean[] visited, int[] parent) {
        // Use ArrayList as a Queue for BFS
        ArrayList<Host> q = new ArrayList<>();

        q.add(start);
        visited[start.index] = true;
        parent[start.index] = -1; // Root has no parent

        int head = 0;
        while (head < q.size()) {
            Host u = q.get(head++);

            for (Tunnel t : u.tunnels) {
                if (t.isSealed) continue;
                Host v = t.target;

                if (!visited[v.index]) {
                    // Found a new node: mark visited, record parent, and enqueue
                    visited[v.index] = true;
                    parent[v.index] = u.index;
                    q.add(v);
                }
                else {
                    // Found a visited node. Check if it is the one we just came from.
                    // If v is NOT our parent, it means we found a different way back to v.
                    // That implies a cycle.
                    if (v.index != parent[u.index]) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
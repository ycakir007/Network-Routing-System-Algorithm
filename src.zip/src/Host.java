//package src;

import java.util.ArrayList;

public class Host {
    int index;
    String id;
    int clearance;
    ArrayList<Tunnel> tunnels;
    boolean isHidden = false;

    public Host(int index, String id, int clearance) {
        this.index = index;
        this.id = id;
        this.clearance = clearance;
        this.tunnels = new ArrayList<>();
    }

    public boolean hasTunnelTo(int targetIdx) {
        for (Tunnel t : tunnels) {
            if (t.target.index == targetIdx) return true;
        }
        return false;
    }

    public Tunnel getTunnelTo(int targetIdx) {
        for (Tunnel t : tunnels) {
            if (t.target.index == targetIdx) return t;
        }
        return null;
    }
}
//package src;

public class Tunnel {
    Host target;
    int latency;
    int bandwidth;
    int firewall;
    boolean isSealed;

    public Tunnel(Host target, int latency, int bandwidth, int firewall) {
        this.target = target;
        this.latency = latency;
        this.bandwidth = bandwidth;
        this.firewall = firewall;
        this.isSealed = false;
    }
}

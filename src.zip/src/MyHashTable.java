//package src;

/**
 * Custom Hash Table for Host objects.
 * Stores Host objects directly, using host.id as the key.
 * Uses Open Addressing with Quadratic Probing.
 */
public class MyHashTable {

    private Host[] table;
    private int size;
    private int capacity;

    // Load factor threshold (e.g., 0.5) to keep probing efficient
    private static final double LOAD_FACTOR = 0.5;

    public MyHashTable() {
        this.capacity = 10007;
        this.table = new Host[capacity];
        this.size = 0;
    }

    /**
     * Inserts a Host into the table.
     */
    public void insert(Host host) {
        // Resize if load factor exceeded
        if ((double) size / capacity >= LOAD_FACTOR) {
            rehash();
        }

        int index = hashFunc(host.id);
        int i = 0;

        while (true) {
            // Found empty spot
            if (table[index] == null) {
                table[index] = host;
                size++;
                return;
            }

            // Collision: Check if it's the same ID (update/overwrite if needed)
            if (table[index].id.equals(host.id)) {
                // In this project, we usually check existence before insert,
                // but strictly speaking, this would overwrite.
                table[index] = host;
                return;
            }

            // Quadratic Probing: index + i^2
            i++;
            index = (index + i * i) % capacity;

            // Handle wrap-around for negative results (unlikely with this math, but good practice)
            if (index < 0) index += capacity;
        }
    }

    /**
     * Finds a Host by its String ID.
     * Returns null if not found.
     */
    public Host get(String id) {
        int index = hashFunc(id);
        int i = 0;

        // Safety limit to prevent infinite loops in bad states
        // In a valid table < 1.0 load, we will eventually find the item or null.
        while (table[index] != null) {
            if (table[index].id.equals(id)) {
                return table[index];
            }

            i++;
            index = (index + i * i) % capacity;
            if (index < 0) index += capacity;
        }

        return null;
    }

    public boolean contains(String id) {
        return get(id) != null;
    }

    /**
     * Standard polynomial hash function for Strings.
     */
    private int hashFunc(String key) {
        int hash = 0;
        int prime = 31;
        for (int i = 0; i < key.length(); i++) {
            hash = (hash * prime + key.charAt(i));
            // Ensure positive index
            if (hash < 0) hash = Math.abs(hash);
        }
        return hash % capacity;
    }

    private void rehash() {
        int newCapacity = capacity * 2; // Ideally next prime, but 2x is fine here
        Host[] oldTable = table;

        this.table = new Host[newCapacity];
        this.capacity = newCapacity;
        this.size = 0; // Reset size, insert() will increment it back

        for (Host h : oldTable) {
            if (h != null) {
                insert(h);
            }
        }
    }
}













//package src;
//
//import java.util.ArrayList;
//
//// Generic Map for Hostname -> Index
// public class MyHashMap<K, V> {
//    private static final int INITIAL_CAPACITY = 200003;
//    private ArrayList<MyHashMap.Entry<K, V>>[] buckets;
//    private int size;
//
//    @SuppressWarnings("unchecked")
//    public MyHashMap() {
//        buckets = new ArrayList[INITIAL_CAPACITY];
//        size = 0;
//    }
//
//    static class Entry<K, V> {
//        K key;
//        V value;
//        Entry(K key, V value) { this.key = key; this.value = value; }
//    }
//
//    public V get(K key) {
//        int idx = (key.hashCode() & 0x7FFFFFFF) % buckets.length;
//        if (buckets[idx] == null) return null;
//        for (MyHashMap.Entry<K, V> e : buckets[idx]) {
//            if (e.key.equals(key)) return e.value;
//        }
//        return null;
//    }
//
//    public void put(K key, V value) {
//        int idx = (key.hashCode() & 0x7FFFFFFF) % buckets.length;
//        if (buckets[idx] == null) {
//            buckets[idx] = new ArrayList<>();
//        }
//        for (MyHashMap.Entry<K, V> e : buckets[idx]) {
//            if (e.key.equals(key)) {
//                e.value = value;
//                return;
//            }
//        }
//        buckets[idx].add(new MyHashMap.Entry<>(key, value));
//        size++;
//    }
//
//    public boolean containsKey(K key) {
//        return get(key) != null;
//    }
//}
//package src;

public class RouteState implements Comparable<RouteState> {
    Host host;
    double totalLatency;
    int hops;
    RouteState parent;

    public RouteState(Host host, double totalLatency, int hops, RouteState parent) {
        this.host = host;
        this.totalLatency = totalLatency;
        this.hops = hops;
        this.parent = parent;
    }

    @Override
    public int compareTo(RouteState other) {
        if (Math.abs(this.totalLatency - other.totalLatency) > 1e-9) {
            return Double.compare(this.totalLatency, other.totalLatency);
        }
        if (this.hops != other.hops) {
            return Integer.compare(this.hops, other.hops);
        }
        return comparePaths(this, other);
    }

    private int comparePaths(RouteState a, RouteState b) {
        if (a == b) return 0;
        if (a == null) return -1;
        if (b == null) return 1;

        if (a.parent == b.parent) {
            return a.host.id.compareTo(b.host.id);
        }
        int val = comparePaths(a.parent, b.parent);
        if (val != 0) return val;
        return a.host.id.compareTo(b.host.id);
    }
}

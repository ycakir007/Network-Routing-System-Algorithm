//package src;

import java.util.ArrayList;

 public class MyPriorityQueue {
    private ArrayList<RouteState> heap;

    public MyPriorityQueue() {
        heap = new ArrayList<>();
    }

    public void add(RouteState element) {
        heap.add(element);
        siftUp(heap.size() - 1);
    }

    public RouteState poll() {
        if (isEmpty()) return null;
        RouteState root = heap.get(0);
        RouteState last = heap.remove(heap.size() - 1);
        if (!isEmpty()) {
            heap.set(0, last);
            siftDown(0);
        }
        return root;
    }

    public boolean isEmpty() {
        return heap.isEmpty();
    }

    private void siftUp(int index) {
        while (index > 0) {
            int parentIndex = (index - 1) / 2;
            if (heap.get(index).compareTo(heap.get(parentIndex)) >= 0) break;
            swap(index, parentIndex);
            index = parentIndex;
        }
    }

    private void siftDown(int index) {
        int size = heap.size();
        while (index < size) {
            int left = 2 * index + 1;
            int right = 2 * index + 2;
            int smallest = index;

            if (left < size && heap.get(left).compareTo(heap.get(smallest)) < 0) {
                smallest = left;
            }
            if (right < size && heap.get(right).compareTo(heap.get(smallest)) < 0) {
                smallest = right;
            }

            if (smallest == index) break;
            swap(index, smallest);
            index = smallest;
        }
    }

    private void swap(int i, int j) {
        RouteState temp = heap.get(i);
        heap.set(i, heap.get(j));
        heap.set(j, temp);
    }
}